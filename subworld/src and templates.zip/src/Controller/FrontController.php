<?php

namespace App\Controller;

use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class FrontController extends AbstractController
{
    #[Route('/', name: 'homepage')]
    public function index(EntityManagerInterface $em): Response
    {
        // Fetch the top 3 popular Subworlds
        $popularSubworlds = $em->createQuery(
            'SELECT s as subworld, COUNT(u.id) as member_count
             FROM App\Entity\Subworld s 
             JOIN s.members u 
             GROUP BY s.id 
             ORDER BY member_count DESC'
        )->setMaxResults(3)->getResult();

        // Fetch all posts with metadata
        $posts = $em->createQuery(
            'SELECT p, u.username AS author, s.name AS subworld, 
                    COUNT(c.id) AS comment_count, 
                    COALESCE(SUM(v.value), 0) AS vote_count
             FROM App\Entity\Post p
             JOIN p.user u
             JOIN p.subworld s
             LEFT JOIN p.comments c
             LEFT JOIN p.votes v
             GROUP BY p.id, u.username, s.name
             ORDER BY p.createdAt DESC'
        )->getResult();

        return $this->render('front/home.html.twig', [
            'popular_subworlds' => array_map(fn($item) => [
                'id' => $item['subworld']->getId(),
                'name' => $item['subworld']->getName(),
                'member_count' => $item['member_count']
            ], $popularSubworlds),
            'posts' => $posts // Pass posts to template
        ]);
    }
}
